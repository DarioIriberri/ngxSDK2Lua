// updateFiles.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <windows.h>
#include <string>
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <tchar.h>

using namespace std;

typedef std::basic_string<TCHAR> tstring;

tstring getDLLPath() {
    TCHAR s[MAX_PATH];
	GetCurrentDirectory(MAX_PATH, s);

    return s;
}

LPTSTR toLPTSTR(tstring param) {
	LPTSTR resp = new TCHAR[param.size() + 1];
	strcpy(resp, param.c_str());

	return resp;
}

int CopyFile(tstring initialFilePath, tstring outputFilePath) {
	ofstream outputFile(outputFilePath.c_str(), ios::out|ios::binary);

	string lineString;
	string writeString;
	ifstream initialFile;
	initialFile.open (initialFilePath);

    while(!initialFile.eof()) {
	    getline(initialFile, lineString);
		writeString += lineString + "\n";
    }
	initialFile.close();

	//And then write out all that was read
	outputFile.write(writeString.c_str(), writeString.size());
	outputFile.close();

	return 0;
}

int UpdateIpcReady(_TCHAR* argv) {
	tstring initialFilePath = (tstring)argv + "\\Modules\\ipcReady.lua";
	tstring outputFilePath = (tstring)argv + "\\Modules\\ipcReady_ngxSDK2Lua_tmp.lua";

	ofstream outputFile(outputFilePath.c_str(), ios::out|ios::binary);

	string str1 ("-- ipc.runlua('startNGXSDK2Lua')");

	string lineString;
	string writeString;
	ifstream initialFile;
	initialFile.open (initialFilePath);

    while(!initialFile.eof()) {
	    getline(initialFile, lineString);
		writeString += lineString + "\n";
    }
	initialFile.close();

	size_t found=writeString.find(str1);

	if (found!=string::npos) {
		writeString.replace(writeString.find(str1), str1.length(), "ipc.runlua('startNGXSDK2Lua')");

	} else {
		string str2 = "ipc.runlua('startNGXSDK2Lua')";
		size_t found=writeString.find(str2);

		if (!(found!=string::npos)) {	
			writeString = "ipc.runlua('startNGXSDK2Lua')\n" + writeString;
		}
	}
	
	//And then write out all that was read
	outputFile.write(writeString.c_str(), writeString.size());
	outputFile.close();

	remove(initialFilePath.c_str());
	rename(outputFilePath.c_str() , initialFilePath.c_str() );

	return 0;
}

int CreateIpcReady(_TCHAR* argv) {
	tstring outputFilePath = (tstring)argv + "\\Modules\\ipcReady.lua";

	ofstream outputFile(outputFilePath.c_str(), ios::out|ios::binary);

	string writeString ("ipc.runlua('startNGXSDK2Lua')");

	//And then write out all that was read
	outputFile.write(writeString.c_str(), writeString.size());
	outputFile.close();

	return 0;
}

int Update737NGX_Options(_TCHAR* argv) {
	tstring initialFilePath = (tstring)argv + "\\PMDG\\PMDG 737 NGX\\737NGX_Options.ini";
	tstring outputFilePath = (tstring)argv + "\\PMDG\\PMDG 737 NGX\\737NGX_Options_tmp.ini";

	ofstream outputFile(outputFilePath.c_str(), ios::out|ios::binary);

	string lineString;
	string writeString;
	ifstream initialFile;
	initialFile.open (initialFilePath);

    while(!initialFile.eof()) {
	    getline(initialFile, lineString);
		writeString += lineString + "\n";
    }
	initialFile.close();

	string str1 ("EnableDataBroadcast=0");
	size_t found=writeString.find(str1);

	if (found!=string::npos) {
		writeString.replace(writeString.find(str1), str1.length(), "EnableDataBroadcast=1");

	} else {
		string str2 = "EnableDataBroadcast=1";
		size_t found=writeString.find(str2);

		if (!(found!=string::npos)) {	
			writeString = "[SDK]\nEnableDataBroadcast=1\n" + writeString;
		}
	}

	//And then write out all that was read
	outputFile.write(writeString.c_str(), writeString.size());

	outputFile.close();

	remove(initialFilePath.c_str());

	rename(outputFilePath.c_str() , initialFilePath.c_str() );

	return 0;
}

int dll_updateFiles(_TCHAR* argv) {
	tstring fileOri = (tstring)argv + "\\Modules\\ipcReady.lua";
	tstring fileDest = (tstring)argv + "\\Modules\\ipcReady_ngxSDK2Lua_bak.lua";

	bool existIpcReady = false;
	bool existIpcReady_ngxSDK2Lua_bak = false;

	if (FILE * file = fopen(fileOri.c_str(), "r")) {
        fclose(file);
        existIpcReady = true;
    }

	if (FILE * file = fopen(fileDest.c_str(), "r")) {
        fclose(file);
        existIpcReady_ngxSDK2Lua_bak = true;
    }

	//MessageBox(NULL, toLPTSTR(fileOri), toLPTSTR(fileOri), MB_OK);
	//MessageBox(NULL, toLPTSTR(fileDest), toLPTSTR(fileDest), MB_OK);

	if (!existIpcReady) {
		CreateIpcReady(argv);
	
	} else if (! existIpcReady_ngxSDK2Lua_bak) {
		CopyFile(toLPTSTR(fileOri), toLPTSTR(fileDest));

		UpdateIpcReady(argv);
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	fileOri = (tstring)argv + "\\PMDG\\PMDG 737 NGX\\737NGX_Options.ini";
	fileDest = (tstring)argv + "\\PMDG\\PMDG 737 NGX\\737NGX_Options_ngxSDK2Lua_bak.ini";

	bool ini737NGX_Options = false;
	bool ini737NGX_Options_ngxSDK2Lua_bak = false;

	if (FILE * file = fopen(fileOri.c_str(), "r")) {
        fclose(file);
        ini737NGX_Options = true;
    }

	if (FILE * file = fopen(fileDest.c_str(), "r")) {
        fclose(file);
        ini737NGX_Options_ngxSDK2Lua_bak = true; 
    }

	//MessageBox(NULL, toLPTSTR(fileOri), toLPTSTR(fileOri), MB_OK);
	//MessageBox(NULL, toLPTSTR(fileDest), toLPTSTR(fileDest), MB_OK);

	if (ini737NGX_Options && ! ini737NGX_Options_ngxSDK2Lua_bak) {
		CopyFile(toLPTSTR(fileOri), toLPTSTR(fileDest));

		Update737NGX_Options(argv);
	}

	return 0;
}

int _tmain(int argc, _TCHAR* argv[]) {
	try {
		dll_updateFiles(argv[1]);

	} catch (...) {
		MessageBox(NULL, "An error ocurred while updating the installation files.\n\nTheinstallation completed sucessfully\nbut you may need to modify the 737NGX_Options.ini and ipcReady.lua files manually.\nSee readme for instructions.", "Error", MB_OK);
	}

	return 0;
}

