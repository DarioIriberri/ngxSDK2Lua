// updateFilesUninstall.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <windows.h>
#include <string>
#include <iostream>
#include <fstream>
#include <stdio.h>
#include <tchar.h>

using namespace std;

typedef std::basic_string<TCHAR> tstring;

int dll_updateFilesUninstallIPCREADY(_TCHAR* argv) {
	tstring initialFilePath = (tstring)argv + "\\Modules\\ipcReady.lua";
	tstring outputFilePath = (tstring)argv + "\\Modules\\ipcReady_ngxSDK2Lua_tmp.lua";

	ofstream outputFile(outputFilePath.c_str(), ios::out|ios::binary);

	string lineString;
	string writeString;
	ifstream initialFile;
	initialFile.open (initialFilePath);

    while(!initialFile.eof()) {
	    getline(initialFile, lineString);
		writeString += lineString + "\n";
    }
	initialFile.close();

	string str1 ("ipc.runlua('startNGXSDK2Lua')");
	size_t found=writeString.find(str1);

	if (found!=string::npos) {
		writeString.replace(found, str1.length(), "-- ipc.runlua('startNGXSDK2Lua')");

		// Delete bak file
		tstring fileOriBak = (tstring)argv + "\\Modules\\ipcReady_ngxSDK2Lua_bak.lua";

		if (FILE * file = fopen(fileOriBak.c_str(), "r")) {
			fclose(file);
			remove(fileOriBak.c_str());
		}
	} 

	//And then write out all that was read
	outputFile.write(writeString.c_str(), writeString.size());

	outputFile.close();

	remove(initialFilePath.c_str());
	rename(outputFilePath.c_str() , initialFilePath.c_str() );
		
	return 0;
}

int dll_updateFilesUninstallPMDGOPTIONS(_TCHAR* argv) {
	tstring initialFilePath = (tstring)argv + "\\PMDG\\PMDG 737 NGX\\737NGX_Options.ini";
	tstring outputFilePath = (tstring)argv + "\\PMDG\\PMDG 737 NGX\\737NGX_Options_tmp.ini";

	ofstream outputFile(outputFilePath.c_str(), ios::out|ios::binary);

	string lineString;
	string writeString;
	ifstream initialFile;
	initialFile.open (initialFilePath);

    while(!initialFile.eof()) {
	    getline(initialFile, lineString);
		writeString += lineString + "\n";
    }
	initialFile.close();

	string str1 ("EnableDataBroadcast=1");
	size_t found=writeString.find(str1);

	if (found!=string::npos) {
		writeString.replace(found, str1.length(), "EnableDataBroadcast=0");

		// Delete bak file
		tstring fileOriBak = (tstring)argv + "\\PMDG\\PMDG 737 NGX\\737NGX_Options_ngxSDK2Lua_bak.ini";

		if (FILE * file = fopen(fileOriBak.c_str(), "r")) {
			fclose(file);
			remove(fileOriBak.c_str());
		}
	} 

	//And then write out all that was read
	outputFile.write(writeString.c_str(), writeString.size());

	outputFile.close();

	remove(initialFilePath.c_str());
	rename(outputFilePath.c_str() , initialFilePath.c_str() );
	
	return 0;
}

int _tmain(int argc, _TCHAR* argv[]) {
	try {
		dll_updateFilesUninstallIPCREADY(argv[1]);
		dll_updateFilesUninstallPMDGOPTIONS(argv[1]);

	} catch (...) {
		MessageBox(NULL, "An error ocurred while updating the installation files.\n\nTheinstallation completed sucessfully\nbut you may need to modify the 737NGX_Options.ini and ipcReady.lua files manually.\nSee readme for instructions.", "Error", MB_OK);
	}
	
	return 0;
}

